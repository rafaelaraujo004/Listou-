
(function(){
  'use strict';

  // ===== Utilitários =====
  const K = {
    ITEMS: 'listou.items.v3',
    HISTORY: 'listou.history.v2',
    SUG: 'listou.suggestions.v1',
    PRICEH: 'listou.pricehist.v1',
    USERLISTS: 'listou.userlists.v1',
    THEME: 'listou.theme',
    THEME_LOCK: 'listou.theme.lock',
    MARKET: 'listou.market.v1'
  };

  const $ = (sel)=>document.querySelector(sel);
  const $$ = (sel)=>Array.from(document.querySelectorAll(sel));
  const money = (n)=> (Number(n)||0).toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
  const genId = ()=> (crypto?.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2));

  // ===== Estado =====
  let items = JSON.parse(localStorage.getItem(K.ITEMS) || '[]');
  let history = JSON.parse(localStorage.getItem(K.HISTORY) || '[]');
  let suggestions = JSON.parse(localStorage.getItem(K.SUG) || '{}');
  let priceHistory = JSON.parse(localStorage.getItem(K.PRICEH) || '{}');
  let userLists = JSON.parse(localStorage.getItem(K.USERLISTS) || '[]');
  let currentMarket = (localStorage.getItem(K.MARKET) || '').trim();

  function save(){
    localStorage.setItem(K.ITEMS, JSON.stringify(items));
    localStorage.setItem(K.HISTORY, JSON.stringify(history));
    localStorage.setItem(K.SUG, JSON.stringify(suggestions));
    localStorage.setItem(K.PRICEH, JSON.stringify(priceHistory));
    localStorage.setItem(K.USERLISTS, JSON.stringify(userLists));
    localStorage.setItem(K.MARKET, currentMarket || '');
  }

  // ===== Tabs =====
  function setTab(id){
    $$('.tab-section').forEach(s=>s.classList.add('hidden'));
    $('#tab-'+id)?.classList.remove('hidden');
  }
  $$('.tab-btn').forEach(btn=>btn.addEventListener('click', ()=> setTab(btn.getAttribute('data-tab')) ));
  setTab('lista');

  // Sidebar mobile
  $('#toggleSidebar')?.addEventListener('click', ()=> $('#sidebar')?.classList.toggle('hidden'));

  // ===== Tema =====
  function applyTheme(t){
    const mode = (t==='light'?'light':'dark');
    document.documentElement.setAttribute('data-theme', mode);
    localStorage.setItem(K.THEME, mode);
    const lbl = $('#themeLabel'); if(lbl) lbl.textContent = (mode==='light'?'Claro':'Escuro');
  }
  function systemTheme(){ return (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) ? 'light':'dark'; }
  function toggleTheme(){
    const cur = localStorage.getItem(K.THEME) || systemTheme();
    const next = cur==='dark'?'light':'dark';
    localStorage.setItem(K.THEME_LOCK,'1');
    applyTheme(next);
  }
  $('#themeToggle')?.addEventListener('click', ()=>{ const ico=$('#themeIcon'); if(ico){ ico.classList.add('spin'); setTimeout(()=>ico.classList.remove('spin'), 300); } toggleTheme(); });
  $('#themeToggle2')?.addEventListener('click', toggleTheme);
  (function initTheme(){
    const stored = localStorage.getItem(K.THEME);
    applyTheme(stored || systemTheme());
    if(!stored && window.matchMedia){
      const mq = window.matchMedia('(prefers-color-scheme: light)');
      const cb = ()=>{ if(!localStorage.getItem(K.THEME_LOCK)) applyTheme(systemTheme()); };
      mq.addEventListener ? mq.addEventListener('change', cb) : mq.addListener(cb);
    }
  })();

  // ===== Gradiente por categoria dominante =====
  const CAT_GRADS = {
    'Mercearia':['#34d399','#065f46'],
    'Laticínios':['#93c5fd','#1e3a8a'],
    'Hortifruti':['#86efac','#14532d'],
    'Limpeza':['#c4b5fd','#4c1d95'],
    'Higiene':['#fca5a5','#7f1d1d'],
    'Bebidas':['#fcd34d','#92400e'],
    'Carnes':['#fda4af','#7f1d1d'],
    'Outros':['#94a3b8','#0f172a']
  };
  function dominantCategory(){
    if(!items.length) return null;
    const totals = {};
    items.forEach(i=>{
      const k=i.category||'Outros';
      totals[k]=(totals[k]||0)+ (Number(i.qty)||0)*(Number(i.price)||0);
    });
    return Object.keys(totals).sort((a,b)=>totals[b]-totals[a])[0] || 'Outros';
  }
  function updateGradient(){ /* tema estável: usa --bg vars do tema */ }

  // ===== ZXing (scanner) =====
  let codeReader = null, currentStream = null;
  const DEMO_DB = { '7894900011517':'Leite UHT 1L','7891000246253':'Arroz 5kg','7891000246260':'Feijão 1kg','7891910000197':'Açúcar 1kg' };
  function ensureZXing(){
    if(!codeReader && window.ZXingBrowser?.BrowserMultiFormatReader){
      codeReader = new ZXingBrowser.BrowserMultiFormatReader();
    }
    return !!codeReader;
  }
  async function startCamera(){
    try{
      if(!ensureZXing()) throw new Error('Biblioteca de scanner não carregou');
      const devices = await navigator.mediaDevices.enumerateDevices();
      const vds = devices.filter(d=>d.kind==='videoinput');
      const back = vds.find(d=>(d.label||'').toLowerCase().includes('back')) || vds[0];
      currentStream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 360, deviceId: back?.deviceId ? { exact: back.deviceId } : undefined } });
      const videoEl = $('#preview'); videoEl.srcObject = currentStream; await videoEl.play(); scanLoop();
    }catch(e){ alert('Câmera indisponível: '+e.message); }
  }
  async function stopCamera(){ if(currentStream){ currentStream.getTracks().forEach(t=>t.stop()); currentStream=null; } if(codeReader){ codeReader.reset(); } }
  async function scanLoop(){
    if(!currentStream || !codeReader) return; const videoEl = $('#preview');
    try{ const result = await codeReader.decodeOnceFromVideoElement(videoEl); if(result?.text){ handleEAN(result.text); } }
    catch(_){ /* ignore NotFound errors */ }
    finally{ if(currentStream) scanLoop(); }
  }
  $('#startScan')?.addEventListener('click', startCamera);
  $('#stopScan')?.addEventListener('click', stopCamera);
  $('#addByEAN')?.addEventListener('click', ()=>{ const code = ($('#manualEAN')?.value||'').trim(); if(code) handleEAN(code); });

  function handleEAN(raw){
    const ean = String(raw).replace(/\D/g,'');
    const name = DEMO_DB[ean] || '';
    const learned = suggestions[name] || suggestions[ean] || null;
    upsertItem({ name: name || ean, category: learned?.lastCategory || 'Outros', unit: learned?.lastUnit || 'un', qty: 1, price: learned?.lastPrice || 0, barcode: ean });
    const m = $('#manualEAN'); if(m) m.value='';
  }

  // ===== Aprendizado e sugestões =====
  function learnFromItem(it){
    if(!it.name) return;
    const key = it.name;
    const s = suggestions[key] || { count:0 };
    s.count = (s.count||0)+1;
    s.lastPrice = it.price;
    s.lastCategory = it.category;
    s.lastUnit = it.unit;
    s.exampleBarcode = it.barcode || s.exampleBarcode || null;
    s.lastAt = Date.now();
    suggestions[key] = s; save(); renderQuickChips();
  }

  function scoreSuggestion(name, meta){
    let s = 0;
    s += (meta.count||0) * 3;
    if(meta.lastPrice>0) s += 2;
    if(meta.lastAt){ const days = (Date.now()-meta.lastAt)/86400000; s += Math.max(0, 5 - Math.min(5, Math.floor(days))); }
    if(priceHistory[name] && currentMarket && priceHistory[name][currentMarket]) s += 2;
    return s;
  }
  function renderQuickChips(){
    const entries = Object.entries(suggestions)
      .map(([n,m])=>[n,m,scoreSuggestion(n,m)])
      .sort((a,b)=>b[2]-a[2])
      .slice(0,8);
    const wrap = $('#quickChips'); if(!wrap) return; wrap.innerHTML='';
    entries.forEach(([rawName, meta])=>{
      const displayName = (window.__RUNNING_TESTS? rawName : rawName.replace(/^\s*(Teste|DEV|TMP)\s+/i,''));
      const hint = meta.lastPrice? (' • '+money(meta.lastPrice)) : '';
      const btn = document.createElement('button');
      btn.className='px-3 py-1 rounded-full bg-white/10 hover:bg-white/20';
      btn.textContent = '+ ' + displayName + hint;
      btn.title = (meta.lastUnit||'un') + ' • ' + (meta.lastCategory||'Outros');
      btn.addEventListener('click', ()=> upsertItem({ name:rawName, category: meta.lastCategory||'Outros', unit: meta.lastUnit||'un', qty: 1, price: meta.lastPrice||0 }) );
      wrap.appendChild(btn);
    });
  }

  // Sugestões de digitação
  const nameInput = $('#name');
  nameInput?.addEventListener('focus', ()=> showSuggestions(''));
  nameInput?.addEventListener('input', (e)=> showSuggestions(e.target.value));
  document.addEventListener('click', (e)=>{ const box=$('#suggestions'); const nm=$('#name'); if(box && !box.contains(e.target) && e.target!==nm) box.classList.add('hidden'); });
  function showSuggestions(query){
    const box = $('#suggestions'); if(!box) return;
    const q = (query||'').toLowerCase();
    const all = Object.keys(suggestions).filter(n=> !q || n.toLowerCase().includes(q)).slice(0,12);
    box.innerHTML='';
    if(!all.length){ box.classList.add('hidden'); return; }
    all.forEach(n=>{
      const m = suggestions[n] || {};
      const display = (window.__RUNNING_TESTS? n : n.replace(/^\s*(Teste|DEV|TMP)\s+/i,''));
      const row = document.createElement('button'); row.type='button';
      row.className='w-full text-left px-3 py-2 rounded-lg hover:bg-white/10 flex items-center gap-2';
      row.innerHTML = '<span class="font-medium">'+display+'</span><span class="text-[11px] muted">'+(m.lastUnit||'un')+' • '+(m.lastCategory||'Outros')+' • '+money(m.lastPrice||0)+'</span>';
      row.addEventListener('click', ()=>{ upsertItem({ name:n, category:m.lastCategory||'Outros', unit:m.lastUnit||'un', qty:1, price:m.lastPrice||0 }); box.classList.add('hidden'); });
      box.appendChild(row);
    });
    box.classList.remove('hidden');
  }

  // ===== CRUD Lista =====
  const listEl = $('#list');

  
function upsertItem(partial){
      // Merge by barcode
      if(partial && partial.barcode){
        var e = items.find(function(i){ return i.barcode===partial.barcode; });
        if(e){
          e.qty = (e.qty||0) + (partial.qty||1);
          if(!e.name && partial.name) e.name = partial.name;
          if(partial.price!=null) e.price = partial.price;
          if(partial.category && !e.category) e.category = partial.category;
          if(partial.unit && !e.unit) e.unit = partial.unit;
          render(); return;
        }
      }
      // Merge by same name (case-insensitive) and same price
      var normName = (partial.name||'').trim().toLowerCase();
      var price = Number(partial.price||0);
      var same = items.find(function(i){
        return (i.name||'').trim().toLowerCase()===normName && Number(i.price||0)===price;
      });
      if(same){
        same.qty = (same.qty||0) + (partial.qty||1);
        if(partial.category && !same.category) same.category = partial.category;
        if(partial.unit && !same.unit) same.unit = partial.unit;
        render(); return;
      }
      var obj = { name:'', category:'Outros', unit:'un', qty:1, price:0, done:false, createdAt:Date.now() };
      for(var k in partial){ if(Object.prototype.hasOwnProperty.call(partial,k)) obj[k]=partial[k]; }
      items.unshift(obj);
    learnFromItem(obj);
    render();
  }

  function trackPriceForHistory(it){
    if(!currentMarket) return;
    const key = it.name || it.barcode || '—';
    priceHistory[key] = priceHistory[key] || {};
    priceHistory[key][currentMarket] = priceHistory[key][currentMarket] || [];
    const arr = priceHistory[key][currentMarket];
    const now = Date.now();
    const last = arr[arr.length-1];
    const price = Number(it.price)||0;
    const sameDay = (ts)=>{ const d1=new Date(ts), d2=new Date(now); return d1.getFullYear()==d2.getFullYear() && d1.getMonth()==d2.getMonth() && d1.getDate()==d2.getDate(); };
    if(!last || last.price !== price || !sameDay(last.at)){ arr.push({ at: now, price }); }
  }

  function render(){
    const sortSel = $('#sort'); const sort = sortSel ? sortSel.value : 'recent';
    const view = items.slice();
    view.sort((a,b)=>{
      if(sort==='name') return (a.name||'').localeCompare(b.name||'');
      if(sort==='price') return (a.price||0)-(b.price||0);
      if(sort==='subtotal') return (a.qty*a.price)-(b.qty*b.price);
      return (b.createdAt||0)-(a.createdAt||0);
    });

    listEl.innerHTML='';
    let total=0, done=0, remaining=0, previsto=0, realizado=0;

    view.forEach((it)=>{
      const idx = items.indexOf(it);
      const subtotal = (Number(it.qty)||0)*(Number(it.price)||0);
      total += subtotal; if(it.done){ done+=subtotal; realizado+=subtotal; } else { remaining+=subtotal; } previsto+=subtotal;

      const tr=document.createElement('tr');
      tr.innerHTML =
        '<td class="px-3 py-2"><input type="checkbox" data-i="'+idx+'" data-act="toggle" '+(it.done?'checked':'')+' class="accent-emerald-500"></td>'+
        '<td class="px-3 py-2">'+
        '  <button class="item-name-btn '+(it.done?'done':'')+'" data-i="'+idx+'" data-act="toggleByName">'+(it.name||'')+'</button>'+
        '  <div class="mt-1 flex items-center gap-2">'+
        '    <input value="'+(it.name||'')+'" data-i="'+idx+'" data-f="name" class="w-full bg-transparent outline-none border-b" style="border-color:var(--ring); display:none" />'+
        '    <button class="icon-btn" data-i="'+idx+'" data-act="editName">✏️</button>'+
        '  </div>'+
        (it.barcode?'<div class="text-[11px] muted">EAN: '+it.barcode+'</div>':'')+
        '</td>'+
        '<td class="px-3 py-2">'+
        '  <select data-i="'+idx+'" data-f="category" class="w-28 bg-transparent outline-none border-b" style="border-color:var(--ring)">'+
             ['Mercearia','Laticínios','Hortifruti','Limpeza','Higiene','Bebidas','Carnes','Outros'].map(c=>'<option '+(c===(it.category||'Outros')?'selected':'')+'>'+c+'</option>').join('')+
        '  </select>'+
        '</td>'+
        '<td class="px-3 py-2">'+
        '  <select data-i="'+idx+'" data-f="unit" class="w-24 bg-transparent outline-none border-b" style="border-color:var(--ring)">'+
             ['un','kg','g','L','ml','pct'].map(u=>'<option '+(u===(it.unit||'un')?'selected':'')+'>'+u+'</option>').join('')+
        '  </select>'+
        '</td>'+
        '<td class="px-3 py-2"><input type="number" min="1" step="1" value="'+it.qty+'" data-i="'+idx+'" data-f="qty" class="w-20 bg-transparent outline-none border-b" style="border-color:var(--ring)" /></td>'+
        '<td class="px-3 py-2"><input type="number" step="0.01" min="0" value="'+it.price+'" data-i="'+idx+'" data-f="price" class="w-28 bg-transparent outline-none border-b" style="border-color:var(--ring)" /></td>'+
        '<td class="px-3 py-2">'+money(subtotal)+'</td>'+
        '<td class="px-3 py-2 text-right"><button data-del="'+idx+'" class="px-2 py-1 rounded-lg bg-rose-600/80 hover:bg-rose-600 text-xs">Remover</button></td>';
      listEl.appendChild(tr);
    });

    $('#grandTotal') && ($('#grandTotal').textContent = money(total));
    $('#count') && ($('#count').textContent = items.length + ' itens');
    $('#progress') && ($('#progress').textContent = 'Concluído: '+money(done)+' • Restante: '+money(remaining));
    $('#kpiPrevisto') && ($('#kpiPrevisto').textContent = money(previsto));
    $('#kpiRealizado') && ($('#kpiRealizado').textContent = money(realizado));
    save();
    renderInsights();
    updateGradient();
  }

  listEl.addEventListener('input', (e)=>{
    const i = Number(e.target.getAttribute('data-i'));
    const f = e.target.getAttribute('data-f');
    if(!Number.isFinite(i) || !f) return;
    let val = e.target.value;
    if(f==='qty' || f==='price') val = Number(val||0);
    items[i][f] = val;
    if(f==='price'){ trackPriceForHistory(items[i]); }
    if(f==='name' || f==='category' || f==='unit' || f==='price') learnFromItem(items[i]);
    save(); render();
  });
  listEl.addEventListener('change', (e)=>{
    if(e.target.getAttribute('data-act')==='toggle'){
      const i = Number(e.target.getAttribute('data-i')); items[i].done = !!e.target.checked; save(); render();
    }
  });
  listEl.addEventListener('click', (e)=>{
    const del = e.target.getAttribute('data-del');
    if(del!=null){ items.splice(Number(del),1); save(); render(); return; }
    const act = e.target.getAttribute('data-act');
    if(act==='toggleByName'){
      const i = Number(e.target.getAttribute('data-i')); if(!Number.isFinite(i)) return;
      items[i].done = !items[i].done; save(); render(); return;
    }
    if(act==='editName'){
      const i = Number(e.target.getAttribute('data-i')); if(!Number.isFinite(i)) return;
      const input = listEl.querySelector('input[data-f="name"][data-i="'+i+'"]');
      if(input){ input.style.display='block'; input.focus(); input.selectionStart = input.value.length; }
    }
  });

  // Form adicionar
  const addForm = $('#addForm');
  addForm?.addEventListener('submit', (e)=>{
    e.preventDefault();
    const it = {
      name: $('#name')?.value?.trim() || '',
      category: $('#category')?.value || 'Outros',
      unit: $('#unit')?.value || 'un',
      qty: Number($('#qty')?.value || 1),
      price: Number($('#price')?.value || 0)
    };
    if(!it.name){ alert('Dê um nome ao item.'); $('#name')?.focus(); return; }
    upsertItem(it); addForm.reset(); $('#qty') && ($('#qty').value=1); $('#unit') && ($('#unit').value='un'); $('#name')?.focus();
  });

  // Templates prontas
  $$('.tpl').forEach(btn=> btn.addEventListener('click', ()=>{
    const arr = JSON.parse(btn.getAttribute('data-template') || '[]');
    arr.forEach(it=> upsertItem(it));
    alert('Lista adicionada à sua lista atual!');
  }));

  // Copiar lista
  $('#copyList')?.addEventListener('click', ()=>{
    const lines = items.map(i=> `${i.name} | ${i.category} | ${i.unit} | ${i.qty} x ${money(i.price)} = ${money(i.qty*i.price)}`);
    const totalText = $('#grandTotal') ? $('#grandTotal').textContent : money(0);
    const text = `Lista — Total: ${totalText}\n` + lines.join('\n');
    if(navigator.clipboard?.writeText){ navigator.clipboard.writeText(text).then(()=>alert('Lista copiada!')).catch(()=>fallbackCopy(text)); }
    else fallbackCopy(text);
  });
  function fallbackCopy(text){ const ta=document.createElement('textarea'); ta.value=text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); alert('Lista copiada!'); }

  // Finalizar compra
  $('#finalizar')?.addEventListener('click', ()=>{
    if(!items.length) return alert('Sua lista está vazia.');
    const total = items.reduce((s,i)=> s + i.qty*i.price, 0);
    const entry = { id: genId(), at: Date.now(), total, items: items.map(i=>{ const o={}; Object.keys(i).forEach(k=> o[k]=i[k]); return o; }) };
    history.unshift(entry);
    entry.items.forEach(trackPriceForHistory);
    items = []; save(); render(); renderReports(); alert('Compra finalizada! Relatórios atualizados.');
  });

  // ===== Insights =====
  let chartCategorias=null, chartABC=null;
  function renderInsights(){
    const total = items.reduce((s,i)=> s + i.qty*i.price, 0);
    const kpiItens = items.length; const ticket = kpiItens? total/kpiItens : 0; const doneVal = items.filter(i=>!!i.done).reduce((s,i)=> s + i.qty*i.price, 0);
    $('#kpiTotal') && ($('#kpiTotal').textContent = money(total));
    $('#kpiItens') && ($('#kpiItens').textContent = String(kpiItens));
    $('#kpiTicket') && ($('#kpiTicket').textContent = money(ticket));
    $('#kpiDone') && ($('#kpiDone').textContent = money(doneVal));

    const catMap={}; items.forEach(i=>{ const c=i.category||'Outros'; catMap[c]=(catMap[c]||0)+i.qty*i.price; });
    const labels=Object.keys(catMap); const data=Object.values(catMap);
    const catCanvas = $('#chartCategorias');
    if(catCanvas){ chartCategorias?.destroy(); chartCategorias = new Chart(catCanvas,{ type:'doughnut', data:{ labels, datasets:[{ data }] }, options:{ plugins:{ legend:{ position:'bottom' }}}}); }

    const sorted = items.slice().sort((a,b)=> (b.qty*b.price)-(a.qty*a.price)).slice(0,8);
    const abcCanvas = $('#chartABC');
    if(abcCanvas){ chartABC?.destroy(); chartABC = new Chart(abcCanvas,{ type:'bar', data:{ labels: sorted.map(i=> i.name||'—'), datasets:[{ data: sorted.map(i=> i.qty*i.price) }] }, options:{ plugins:{ legend:{ display:false }}, scales:{ y:{ beginAtZero:true }}}}); }
  }

  // ===== Relatórios =====
  let chartMes=null, chartFreq=null, chartItemMarket=null, chartRankingVar=null;

  function refreshReportItemSelect(){
    const sel = $('#reportItemSelect'); if(!sel) return;
    const set = new Set(); history.forEach(h=> h.items.forEach(i=> i.name && set.add(i.name) )); items.forEach(i=> i.name && set.add(i.name));
    const names = Array.from(set).sort(); sel.innerHTML=''; names.forEach(n=>{ const o=document.createElement('option'); o.value=n; o.textContent=n; sel.appendChild(o); });
    if(!sel.value && names.length) sel.value = names[0];
  }
  function renderMarketComparison(){
    const sel = $('#reportItemSelect'); if(!sel) return;
    const name = sel.value; if(!name) return;
    const markets = priceHistory[name] ? Object.keys(priceHistory[name]) : [];
    const labels = markets;
    const data = markets.map(m=>{ const arr = priceHistory[name][m]||[]; const last = arr[arr.length-1]; return last? last.price: 0; });
    const ctx = $('#chartItemMarket');
    if(ctx){ chartItemMarket?.destroy(); chartItemMarket = new Chart(ctx,{ type:'bar', data:{ labels, datasets:[{ label:'Preço mais recente', data }] }, options:{ plugins:{ legend:{ position:'bottom' }}, scales:{ y:{ beginAtZero:true }}} }); }
  }
  function computeVariationRanking(){
    const entries = [];
    Object.keys(priceHistory).forEach(name=>{
      const markets = priceHistory[name];
      const lastVals=[], prevVals=[];
      Object.keys(markets).forEach(m=>{ const arr=markets[m]; if(arr.length){ lastVals.push(arr[arr.length-1].price); if(arr.length>1) prevVals.push(arr[arr.length-2].price); } });
      if(lastVals.length && prevVals.length){
        const lastAvg = lastVals.reduce((a,b)=>a+b,0)/lastVals.length;
        const prevAvg = prevVals.reduce((a,b)=>a+b,0)/prevVals.length;
        if(prevAvg>0){ const delta = (lastAvg-prevAvg)/prevAvg*100; entries.push([name, delta]); }
      }
    });
    entries.sort((a,b)=> Math.abs(b[1]) - Math.abs(a[1]) );
    return entries.slice(0,10);
  }
  function renderRankingVar(){
    const top = computeVariationRanking();
    const labels = top.map(x=>x[0]);
    const data = top.map(x=> Number(x[1].toFixed(1)));
    const ctx = $('#chartRankingVar');
    if(ctx){ chartRankingVar?.destroy(); chartRankingVar = new Chart(ctx,{ type:'bar', data:{ labels, datasets:[{ label:'∆% (último vs anterior)', data }] }, options:{ plugins:{ legend:{ position:'bottom' }}, scales:{ y:{ beginAtZero:true }}} }); }
  }

  function renderReports(){
    refreshReportItemSelect();
    const sel=$('#reportItemSelect'); if(sel){ sel.onchange = ()=>{ renderMarketComparison(); }; }
    renderMarketComparison(); renderRankingVar();

    const byMonth = {};
    history.forEach(h=>{ const d=new Date(h.at); const k=d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0'); byMonth[k]=(byMonth[k]||0)+h.total; });
    const mLabels = Object.keys(byMonth).sort(); const mData = mLabels.map(k=> byMonth[k]);
    const mesCanvas = $('#chartGastosMes');
    if(mesCanvas){ chartMes?.destroy(); chartMes = new Chart(mesCanvas,{ type:'line', data:{ labels:mLabels, datasets:[{ label:'Gastos (R$)', data:mData, tension:0.2 }] }, options:{ plugins:{ legend:{ position:'bottom' }}}}); }

    const freq = {};
    history.forEach(h=> h.items.forEach(i=>{ const k=i.name||'—'; freq[k]=(freq[k]||0)+i.qty; }));
    const fEntries = Object.entries(freq).sort((a,b)=> b[1]-a[1]).slice(0,10);
    const fLabels = fEntries.map(x=>x[0]); const fData = fEntries.map(x=>x[1]);
    const freqCanvas = $('#chartFreq');
    if(freqCanvas){ chartFreq?.destroy(); chartFreq = new Chart(freqCanvas,{ type:'bar', data:{ labels:fLabels, datasets:[{ label:'Frequência', data:fData }] }, options:{ plugins:{ legend:{ position:'bottom' }}, scales:{ y:{ beginAtZero:true }}}}); }
  }

  // ===== Mercado =====
  const marketInput = $('#market'); const saveMarketBtn = $('#saveMarket');
  if(marketInput) marketInput.value = currentMarket || '';
  saveMarketBtn?.addEventListener('click', ()=>{ currentMarket = (marketInput.value||'').trim(); save(); alert('Mercado salvo: '+(currentMarket||'—')); });

  // ===== User Lists =====
  function renderUserLists(){
    const box = $('#userLists'); if(!box) return;
    box.innerHTML='';
    if(!userLists.length){ box.innerHTML = '<div class="text-sm opacity-70">Nenhuma lista salva ainda.</div>'; return; }
    userLists.forEach((ul, idx)=>{
      const row = document.createElement('div');
      row.className = 'flex items-center justify-between bg-white/5 rounded-lg p-2';
      row.innerHTML = '<span class="font-medium">'+(ul.name||('Lista '+(idx+1)))+'</span>'+
                      '<div class="flex gap-2">'+
                      '<button data-act="use" data-i="'+idx+'" class="px-2 py-1 rounded bg-emerald-600/80 hover:bg-emerald-600 text-xs">Adicionar à lista</button>'+
                      '<button data-act="rename" data-i="'+idx+'" class="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-xs">Renomear</button>'+
                      '<button data-act="del" data-i="'+idx+'" class="px-2 py-1 rounded bg-rose-600/80 hover:bg-rose-600 text-xs">Excluir</button>'+
                      '</div>';
      box.appendChild(row);
    });
    box.onclick = (e)=>{
      const act = e.target.getAttribute('data-act'); if(!act) return;
      const i = Number(e.target.getAttribute('data-i')); const model = userLists[i];
      if(act==='use'){ model.items.forEach(it=> upsertItem(it)); }
      if(act==='rename'){ const nn = prompt('Novo nome da lista:', model.name||('Lista '+(i+1))); if(nn){ userLists[i].name = nn.trim(); save(); renderUserLists(); } }
      if(act==='del'){ if(confirm('Excluir esta lista?')){ userLists.splice(i,1); save(); renderUserLists(); } }
    };
  }
  $('#saveCurrentAsList')?.addEventListener('click', ()=>{
    if(!items.length) return alert('A lista atual está vazia.');
    const nm = prompt('Nome para esta lista:','Minha lista'); if(!nm) return;
    userLists.push({ name: nm.trim(), items: items.map(i=>{ const o={}; ['name','category','unit','qty','price','barcode'].forEach(k=> o[k]=i[k]); return o; }) });
    save(); renderUserLists(); alert('Lista salva!');
  });

  // ===== Inicialização =====
  function init(){
    renderQuickChips();
    render();
    renderReports();
    renderUserLists();
    // testes simples de sanidade (dev)
    window.__listou = { items, history, suggestions, priceHistory, render, renderReports };
  }
  init();
})();